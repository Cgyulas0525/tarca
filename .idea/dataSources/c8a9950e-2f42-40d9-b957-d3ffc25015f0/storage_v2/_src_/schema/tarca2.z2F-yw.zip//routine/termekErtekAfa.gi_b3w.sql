create
    definer = root@localhost function termekErtekAfa(raId int, raErtek int) returns int deterministic
BEGIN
	DECLARE afaErtek INT(10);
    DECLARE afa INT(10);
    DECLARE afaSzazalek INT(10);
    SET afaErtek = 0;
    SELECT termekcsoport.afa INTO afa FROM termek, termekcsoport 
	 WHERE termek.id = raId AND termekcsoport.id = termek.csoport;
	SET afaSzazalek = afaSzazalekErtek(afa);
    SET afaErtek = ROUND((raErtek / (100 + afaSzazalek)), 0) * afaSzazalek; 
	RETURN afaErtek;
END;

