create
    definer = root@localhost function afaSzazalekErtek(id int) returns int(10)
BEGIN
	DECLARE szazalek INT(10);
    SET szazalek = 0;
    CASE
		WHEN id = 2081 THEN SET szazalek = 0;
		WHEN id = 2082 THEN SET szazalek = 5;
		WHEN id = 2083 THEN SET szazalek = 27;
		WHEN id = 2084 THEN SET szazalek = 0;
		ELSE SET szazalek = 18;
	END CASE;
	RETURN szazalek;
END;

