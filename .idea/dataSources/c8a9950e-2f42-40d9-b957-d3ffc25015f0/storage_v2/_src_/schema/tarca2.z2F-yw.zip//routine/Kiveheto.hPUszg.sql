create
    definer = root@localhost function Kiveheto(raId int) returns int
BEGIN
	DECLARE v_sum INT(10);
    DECLARE v_kartya INT(10);
	
    SELECT t.kartya, PenztarSum(t.id) INTO v_kartya, v_sum 
      FROM zaras t WHERE t.id = raId;
	SET v_sum = v_sum - v_kartya;
RETURN(v_sum);
END;

