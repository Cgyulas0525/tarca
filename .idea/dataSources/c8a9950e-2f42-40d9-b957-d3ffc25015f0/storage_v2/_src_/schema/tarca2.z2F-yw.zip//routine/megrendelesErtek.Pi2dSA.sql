create
    definer = root@localhost function megrendelesErtek(raId int) returns int deterministic
BEGIN
	DECLARE v_sum INT(10);
    SELECT sum(t.ertek) INTO v_sum 
      FROM megrendelestetel t WHERE t.megrendelesfej = raId;
RETURN(v_sum);
END;

