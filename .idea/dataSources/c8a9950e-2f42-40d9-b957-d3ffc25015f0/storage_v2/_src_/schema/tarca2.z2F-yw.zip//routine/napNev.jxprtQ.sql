create
    definer = root@localhost function napNev(raDate date) returns varchar(20) deterministic
BEGIN
	DECLARE vNev VARCHAR(20);
    DECLARE vNap INT(1);
    
    SELECT DAYOFWEEK(raDate) INTO vNap;
    CASE
		WHEN vNap = 2 THEN SET vNev = 'Hétfö';
		WHEN vNap = 3 THEN SET vNev = 'Kedd';
		WHEN vNap = 4 THEN SET vNev = 'Szerda';
		WHEN vNap = 5 THEN SET vNev = 'Csütörtök';
		WHEN vNap = 6 THEN SET vNev = 'Péntek';
		WHEN vNap = 7 THEN SET vNev = 'Szombat';
		ELSE SET vNev = 'Vasárnap';
	END CASE;
	RETURN vNev;
END;

